#!/usr/bin/env bash
set -euo pipefail

DOMAIN="${1:-}"
APP="/var/www/idris-dep"

if [[ -z "$DOMAIN" ]]; then
  echo "Использование: sudo bash deploy/setup.sh example.com"
  exit 1
fi

apt update
apt install -y nginx unzip curl

if ! command -v node >/dev/null 2>&1; then
  echo "Установите Node.js 18+ перед запуском этого скрипта."
  exit 1
fi

mkdir -p "$APP"
cp -r public server.js package.json README.md .env.example "$APP/" 2>/dev/null || true
cd "$APP"
npm install --omit=dev

id -u www-data >/dev/null 2>&1 || useradd --system --no-create-home www-data
chown -R www-data:www-data "$APP"

sed "s/YOUR_DOMAIN_HERE/$DOMAIN/g" deploy/nginx.conf > /etc/nginx/sites-available/idris-dep
ln -sf /etc/nginx/sites-available/idris-dep /etc/nginx/sites-enabled/idris-dep
rm -f /etc/nginx/sites-enabled/default

cp deploy/idris-dep.service /etc/systemd/system/idris-dep.service
systemctl daemon-reload
systemctl enable --now idris-dep

nginx -t
systemctl reload nginx

echo
echo "Idris/dep запущен."
echo "Откройте: http://$DOMAIN"
echo
echo "Для HTTPS выполните:"
echo "  apt install -y certbot python3-certbot-nginx"
echo "  certbot --nginx -d $DOMAIN"
