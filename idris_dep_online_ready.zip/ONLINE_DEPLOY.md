# Idris/dep — размещение онлайн

## 1. VPS
Создайте VPS с Ubuntu 24.04 и получите IP.

## 2. DNS
У регистратора домена создайте A-запись:

    @  -> IP_ВАШЕГО_VPS

И при необходимости:

    www -> IP_ВАШЕГО_VPS

Дождитесь обновления DNS.

## 3. Загрузите проект
Загрузите содержимое этого архива на VPS в `/var/www/idris-dep`.

Например, если архив уже на сервере:

    mkdir -p /var/www/idris-dep
    cd /var/www/idris-dep
    unzip idris_dep_online_ready.zip

## 4. Запуск
Убедитесь, что Node.js 18+ установлен:

    node -v
    npm -v

Затем:

    cd /var/www/idris-dep
    sudo bash deploy/setup.sh YOUR_DOMAIN

Например:

    sudo bash deploy/setup.sh idris-dep.com

## 5. HTTPS
После того как HTTP открывается:

    sudo apt install -y certbot python3-certbot-nginx
    sudo certbot --nginx -d idris-dep.com

После этого сайт будет доступен по HTTPS.

## 6. Проверка

    sudo systemctl status idris-dep
    sudo journalctl -u idris-dep -f

Nginx:

    sudo nginx -t

База SQLite находится в:

    /var/www/idris-dep/royalbet.sqlite

Сделайте регулярные резервные копии этой базы.

## Важно
Это демонстрационное казино с виртуальными фишками. Реальные деньги, депозиты и вывод средств не реализованы.
