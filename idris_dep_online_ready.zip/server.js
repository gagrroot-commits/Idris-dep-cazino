
'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const Database = require('better-sqlite3');

const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '0.0.0.0';
const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const DB_PATH = process.env.DB_PATH || path.join(ROOT, 'idris_dep.sqlite');

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE COLLATE NOCASE,
  password_hash TEXT NOT NULL,
  salt TEXT NOT NULL,
  balance INTEGER NOT NULL DEFAULT 1000,
  rounds INTEGER NOT NULL DEFAULT 0,
  best_win INTEGER NOT NULL DEFAULT 0,
  last_bonus TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS sessions (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS rounds (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  game TEXT NOT NULL,
  bet INTEGER NOT NULL,
  profit INTEGER NOT NULL,
  result TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS game_states (
  user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  game TEXT NOT NULL,
  state_json TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
`);

const stmt = {
  userByEmail: db.prepare('SELECT * FROM users WHERE email = ? COLLATE NOCASE'),
  userById: db.prepare('SELECT * FROM users WHERE id = ?'),
  createUser: db.prepare('INSERT INTO users (name,email,password_hash,salt) VALUES (?,?,?,?)'),
  updateBalance: db.prepare('UPDATE users SET balance=?, rounds=?, best_win=? WHERE id=?'),
  bonus: db.prepare('UPDATE users SET balance=balance+500,last_bonus=? WHERE id=?'),
  session: db.prepare('INSERT INTO sessions(token,user_id,expires_at) VALUES (?,?,?)'),
  getSession: db.prepare('SELECT user_id FROM sessions WHERE token=? AND expires_at>?'),
  deleteSession: db.prepare('DELETE FROM sessions WHERE token=?'),
  deleteExpired: db.prepare('DELETE FROM sessions WHERE expires_at<=?'),
  addRound: db.prepare('INSERT INTO rounds(user_id,game,bet,profit,result) VALUES(?,?,?,?,?)'),
  history: db.prepare("SELECT result FROM rounds WHERE user_id=? AND game='roulette' ORDER BY id DESC LIMIT 12"),
  getState: db.prepare('SELECT state_json FROM game_states WHERE user_id=? AND game=?'),
  putState: db.prepare(`
    INSERT INTO game_states(user_id,game,state_json,updated_at) VALUES(?,?,?,CURRENT_TIMESTAMP)
    ON CONFLICT(user_id) DO UPDATE SET game=excluded.game,state_json=excluded.state_json,updated_at=CURRENT_TIMESTAMP
  `),
  deleteState: db.prepare("DELETE FROM game_states WHERE user_id=? AND game='blackjack'")
};

function json(res, status, data, extraHeaders={}) {
  const body = JSON.stringify(data);
  res.writeHead(status, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store',...extraHeaders});
  res.end(body);
}
function readBody(req) {
  return new Promise((resolve,reject)=>{
    let body='', size=0;
    req.on('data', chunk => {
      size += chunk.length;
      if(size > 1_000_000){reject(new Error('Слишком большой запрос'));req.destroy();return;}
      body += chunk;
    });
    req.on('end', ()=>{
      try{resolve(body ? JSON.parse(body) : {})}catch(e){reject(new Error('Некорректный JSON'))}
    });
    req.on('error',reject);
  });
}
function cookie(req,name){
  const raw=req.headers.cookie||'';
  const found=raw.split(';').map(x=>x.trim()).find(x=>x.startsWith(name+'='));
  return found ? decodeURIComponent(found.slice(name.length+1)) : null;
}
function setSessionCookie(res, token) {
  res.setHeader('Set-Cookie', `session=${encodeURIComponent(token)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=604800`);
}
function clearSessionCookie(res){
  res.setHeader('Set-Cookie','session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0');
}
function publicUser(u){
  return {id:u.id,name:u.name,email:u.email,balance:u.balance,rounds:u.rounds,bestWin:u.best_win};
}
function requireUser(req,res){
  stmt.deleteExpired.run(Date.now());
  const token=cookie(req,'session');
  if(!token){json(res,401,{error:'Войдите в аккаунт'});return null;}
  const s=stmt.getSession.get(token,Date.now());
  if(!s){clearSessionCookie(res);json(res,401,{error:'Сессия истекла'});return null;}
  const u=stmt.userById.get(s.user_id);
  if(!u){clearSessionCookie(res);json(res,401,{error:'Пользователь не найден'});return null;}
  return {user:u,token};
}

function hashPassword(password,salt){
  return crypto.scryptSync(password,salt,64).toString('hex');
}
function validEmail(v){return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);}
function cleanName(v){return String(v||'').trim().replace(/\s+/g,' ');}
function publicGame(user, game){
  return {user:publicUser(user),game};
}
function randomInt(max){return crypto.randomInt(0,max);}
function rouletteColor(n){
  if(n===0)return 'green';
  return [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36].includes(n)?'red':'black';
}
function roundResult(u, game, bet, profit, result){
  const newBalance=u.balance + profit;
  const best=Math.max(u.best_win, Math.max(0,profit));
  const rounds=u.rounds+1;
  stmt.updateBalance.run(newBalance,rounds,best,u.id);
  stmt.addRound.run(u.id,game,bet,profit,JSON.stringify(result));
  return stmt.userById.get(u.id);
}

function deck(){
  const suits=['♠','♥','♦','♣'], ranks=['A','2','3','4','5','6','7','8','9','10','J','Q','K'];
  const d=[];
  for(const s of suits)for(const r of ranks)d.push({s,r});
  for(let i=d.length-1;i>0;i--){const j=randomInt(i+1);[d[i],d[j]]=[d[j],d[i]];}
  return d;
}
function value(hand){
  let total=0, aces=0;
  for(const c of hand){
    if(c.r==='A'){total+=11;aces++;}
    else total += ['K','Q','J'].includes(c.r)?10:Number(c.r);
  }
  while(total>21&&aces>0){total-=10;aces--;}
  return total;
}
function saveBJ(userId,state){stmt.putState.run(userId,'blackjack',JSON.stringify(state));}
function loadBJ(userId){
  const row=stmt.getState.get(userId,'blackjack');
  return row?JSON.parse(row.state_json):null;
}

async function route(req,res){
  const url=new URL(req.url,`http://${req.headers.host||'localhost'}`);
  const p=url.pathname;

  if(req.method==='GET' && p==='/api/me'){
    const auth=requireUser(req,res);
    if(!auth)return;
    const h=stmt.history.all(auth.user.id).map(x=>Number(JSON.parse(x.result)));
    const bj=loadBJ(auth.user.id);
    const game=bj?{
      player:bj.player,dealer:bj.dealer,playerScore:value(bj.player),
      dealerScore:value(bj.dealer),active:bj.active,finished:!bj.active,
      message:bj.message||'Твой ход',win:!!bj.win,push:!!bj.push
    }:null;
    return json(res,200,{user:publicUser(auth.user),history:h,blackjack:game});
  }

  if(req.method==='POST' && p==='/api/register'){
    const b=await readBody(req), name=cleanName(b.name), email=String(b.email||'').trim().toLowerCase(), password=String(b.password||'');
    if(name.length<2||name.length>24)return json(res,400,{error:'Имя: от 2 до 24 символов'});
    if(!validEmail(email))return json(res,400,{error:'Введите корректный email'});
    if(password.length<6||password.length>128)return json(res,400,{error:'Пароль: от 6 до 128 символов'});
    if(stmt.userByEmail.get(email))return json(res,409,{error:'Этот email уже зарегистрирован'});
    const salt=crypto.randomBytes(16).toString('hex'), hash=hashPassword(password,salt);
    const info=stmt.createUser.run(name,email,hash,salt);
    const token=crypto.randomBytes(32).toString('hex');
    stmt.session.run(token,info.lastInsertRowid,Date.now()+7*24*60*60*1000);
    const u=stmt.userById.get(info.lastInsertRowid);
    setSessionCookie(res,token);
    return json(res,201,{user:publicUser(u)});
  }

  if(req.method==='POST' && p==='/api/login'){
    const b=await readBody(req), email=String(b.email||'').trim().toLowerCase(), password=String(b.password||'');
    const u=stmt.userByEmail.get(email);
    if(!u || !crypto.timingSafeEqual(Buffer.from(hashPassword(password,u.salt),'hex'),Buffer.from(u.password_hash,'hex')))
      return json(res,401,{error:'Неверный email или пароль'});
    const token=crypto.randomBytes(32).toString('hex');
    stmt.session.run(token,u.id,Date.now()+7*24*60*60*1000);
    setSessionCookie(res,token);
    return json(res,200,{user:publicUser(u)});
  }

  if(req.method==='POST' && p==='/api/logout'){
    const token=cookie(req,'session'); if(token)stmt.deleteSession.run(token);
    clearSessionCookie(res); return json(res,200,{ok:true});
  }

  if(req.method==='POST' && p==='/api/bonus'){
    const auth=requireUser(req,res); if(!auth)return;
    const today=new Date().toISOString().slice(0,10);
    if(auth.user.last_bonus===today)return json(res,200,{claimed:false,user:publicUser(auth.user)});
    stmt.bonus.run(today,auth.user.id);
    const u=stmt.userById.get(auth.user.id);
    return json(res,200,{claimed:true,user:publicUser(u)});
  }

  if(req.method==='POST' && p==='/api/games/slots'){
    const auth=requireUser(req,res); if(!auth)return;
    const b=await readBody(req), bet=Math.floor(Number(b.bet));
    if(!Number.isInteger(bet)||bet<1)return json(res,400,{error:'Ставка должна быть целым числом от 1'});
    if(bet>auth.user.balance)return json(res,400,{error:'Недостаточно фишек'});
    const symbols=['🍒','🍋','🔔','💎','7️⃣'], payout={'🍒':5,'🍋':10,'🔔':15,'💎':25,'7️⃣':50};
    const result={symbols:[symbols[randomInt(5)],symbols[randomInt(5)],symbols[randomInt(5)]]};
    result.win=result.symbols[0]===result.symbols[1]&&result.symbols[1]===result.symbols[2];
    const winAmount=result.win?bet*payout[result.symbols[0]]:0;
    const profit=winAmount-bet;
    result.winAmount=winAmount; result.profit=profit;
    const u=roundResult(auth.user,'slots',bet,profit,result);
    return json(res,200,{user:publicUser(u),result});
  }

  if(req.method==='POST' && p==='/api/games/roulette'){
    const auth=requireUser(req,res); if(!auth)return;
    const b=await readBody(req), bet=Math.floor(Number(b.bet)), type=String(b.type||'');
    const allowed=['red','black','even','odd','low','high'];
    if(!Number.isInteger(bet)||bet<1)return json(res,400,{error:'Ставка должна быть целым числом от 1'});
    if(!allowed.includes(type))return json(res,400,{error:'Выберите тип ставки'});
    if(bet>auth.user.balance)return json(res,400,{error:'Недостаточно фишек'});
    const n=randomInt(37), color=rouletteColor(n);
    const win=(type==='red'&&color==='red')||(type==='black'&&color==='black')||
      (type==='even'&&n>0&&n%2===0)||(type==='odd'&&n%2===1)||
      (type==='low'&&n>=1&&n<=18)||(type==='high'&&n>=19&&n<=36);
    const profit=win?bet:-bet;
    const result={number:n,color,win,profit};
    const u=roundResult(auth.user,'roulette',bet,profit,result);
    return json(res,200,{user:publicUser(u),result});
  }

  if(req.method==='POST' && p.startsWith('/api/games/blackjack/')){
    const auth=requireUser(req,res); if(!auth)return;
    const action=p.split('/').pop();

    if(action==='deal'){
      const b=await readBody(req), bet=Math.floor(Number(b.bet));
      if(!Number.isInteger(bet)||bet<1)return json(res,400,{error:'Ставка должна быть целым числом от 1'});
      if(bet>auth.user.balance)return json(res,400,{error:'Недостаточно фишек'});
      const d=deck(), player=[d.pop(),d.pop()], dealer=[d.pop(),d.pop()];
      const state={bet,player,dealer,active:true,finished:false,message:'Твой ход',win:false,push:false};
      if(value(player)===21){
        const payout=Math.floor(bet*2.5), profit=payout-bet;
        state.active=false;state.finished=true;state.win=true;state.message='🃏 Блэкджек! +'+payout+' фишек';
        const u=roundResult(auth.user,'blackjack',bet,profit,{player,dealer,result:'blackjack',profit});
        stmt.deleteState.run(auth.user.id);
        return json(res,200,{user:publicUser(u),game:{...state,playerScore:21,dealerScore:value(dealer)}});
      }
      saveBJ(auth.user.id,state);
      const u=stmt.userById.get(auth.user.id);
      return json(res,200,{user:publicUser(u),game:{...state,playerScore:value(player),dealerScore:value(dealer)}});
    }

    const state=loadBJ(auth.user.id);
    if(!state||!state.active)return json(res,400,{error:'Активной игры нет'});
    if(action==='hit'){
      const d=deck(); // only use one random card from a fresh shuffled deck for demo simplicity
      state.player.push(d.pop());
      const pv=value(state.player);
      if(pv>21){
        state.active=false;state.finished=true;state.win=false;state.message='Перебор — проигрыш';
        const u=roundResult(auth.user,'blackjack',state.bet,-state.bet,{player:state.player,dealer:state.dealer,result:'bust',profit:-state.bet});
        stmt.deleteState.run(auth.user.id);
        return json(res,200,{user:publicUser(u),game:{...state,playerScore:pv,dealerScore:value(state.dealer)}});
      }
      if(pv===21){
        // Automatically stand at 21.
        while(value(state.dealer)<17)state.dealer.push(d.pop());
        const dv=value(state.dealer), profit=dv>21||pv>dv?state.bet:(pv===dv?0:-state.bet);
        state.active=false;state.finished=true;state.win=profit>0;state.push=profit===0;
        state.message=profit>0?`Победа! Ты ${pv}, дилер ${dv} · +${state.bet} фишек`:(profit===0?`Ничья ${pv}:${dv} · ставка возвращена`:`Проигрыш ${pv}:${dv}`);
        const u=roundResult(auth.user,'blackjack',state.bet,profit,{player:state.player,dealer:state.dealer,result:state.message,profit});
        stmt.deleteState.run(auth.user.id);
        return json(res,200,{user:publicUser(u),game:{...state,playerScore:pv,dealerScore:dv}});
      }
      saveBJ(auth.user.id,state); const u=stmt.userById.get(auth.user.id);
      return json(res,200,{user:publicUser(u),game:{...state,playerScore:pv,dealerScore:value(state.dealer)}});
    }

    if(action==='stand'){
      while(value(state.dealer)<17){
        const d=deck(); state.dealer.push(d.pop());
      }
      const pv=value(state.player),dv=value(state.dealer);
      let profit;
      if(dv>21||pv>dv)profit=state.bet;
      else if(pv===dv)profit=0;
      else profit=-state.bet;
      state.active=false;state.finished=true;state.win=profit>0;state.push=profit===0;
      state.message=profit>0?`Победа! Ты ${pv}, дилер ${dv} · +${state.bet} фишек`:(profit===0?`Ничья ${pv}:${dv} · ставка возвращена`:`Проигрыш ${pv}:${dv}`);
      const u=roundResult(auth.user,'blackjack',state.bet,profit,{player:state.player,dealer:state.dealer,result:state.message,profit});
      stmt.deleteState.run(auth.user.id);
      return json(res,200,{user:publicUser(u),game:{...state,playerScore:pv,dealerScore:dv}});
    }
    return json(res,404,{error:'Неизвестное действие'});
  }

  if(req.method==='GET'){
    let file=p==='/'?'/index.html':p;
    const safe=path.normalize(file).replace(/^(\.\.[\/\\])+/, '');
    const full=path.join(PUBLIC,safe);
    if(!full.startsWith(PUBLIC))return json(res,403,{error:'Forbidden'});
    if(fs.existsSync(full)&&fs.statSync(full).isFile()){
      const ext=path.extname(full);
      const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg'};
      res.writeHead(200,{'Content-Type':types[ext]||'application/octet-stream'});
      return fs.createReadStream(full).pipe(res);
    }
  }

  json(res,404,{error:'Not found'});
}

const server=http.createServer((req,res)=>{
  route(req,res).catch(err=>{
    console.error(err);
    if(!res.headersSent)json(res,500,{error:'Внутренняя ошибка сервера'});
    else res.end();
  });
});
server.listen(PORT,HOST,()=>console.log(`Idris/dep multiplayer: http://${HOST}:${PORT}`));
